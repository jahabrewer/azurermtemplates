configuration DCJoin
{
    param 
    ( 
        [string[]]$NodeName="localhost", 
 
        [Parameter(Mandatory)] 
        [string]$MachineName, 
 
        [Parameter(Mandatory)] 
        [string]$Domain, 
 
        [Parameter(Mandatory)] 
        [pscredential]$DomainCredential 
    ) 
 
    #Import the required DSC Resources 
    Import-DscResource -Module cComputerManagement 
 
    Node $NodeName 
    { 
		<#
        Script FooBar
		{
			SetScript = {
				Write-Verbose "Set-Script"
			}	
			GetScript = {
				return @{"Something" = "Something Else"}
			}
			TestScript = {
				Write-Verbose $using:DomainCredential.GetNetworkCredential().Password
				return true
			}
		}
		#>
		
		cComputer JoinDomain 
        { 
            Name          = $MachineName  
            DomainName    = $Domain
            Credential    = $DomainCredential  # Credential to join to domain 
        } 
		
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true
		}
		
		Log logFinished
		{
			Message = "Finished"
			DependsOn = "[cComputer]JoinDomain"
		}
    } 
}
