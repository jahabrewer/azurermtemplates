﻿$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName="localhost"
            PSDscAllowPlainTextPassword=$true
         }
    )
}

Configuration SessionVDA
{

    Param
    (
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $mediaUri,

        [Parameter(Mandatory)]
        [string]$MachineName,
 
        [Parameter(Mandatory)]
        [string]$Domain,
 
        [Parameter(Mandatory)]
        [pscredential]$DomainCredential,
 
        [Parameter(Mandatory)]
        [string]$XenDesktopController
    )

    Import-DscResource -Module CitrixXenDesktop
    Import-DscResource -Module xPsDesiredStateConfiguration
    Import-DscResource -Module DiskImage
    Import-DscResource -Module cComputerManagement

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
		
		cComputer JoinDomain
        {
            Name          = $MachineName
            DomainName    = $Domain
            Credential    = $DomainCredential  # Credential to join to domain
        }

        File citrixFolder
        {
            Ensure = "Present"
            Type = "Directory"
            DestinationPath = "$env:ProgramData\Citrix\EasyButton"
            DependsOn = "[cComputer]JoinDomain"
        }

        xRemoteFile xdMedia
        {
            DestinationPath = "$env:ProgramData\Citrix\XenDesktop75.zip"
            Uri = $mediaUri
            DependsOn = "[File]citrixFolder"
        }

        Archive xdMediaUnzip
        {
            Ensure = "Present"
            Path = "$env:ProgramData\Citrix\XenDesktop75.zip"
            Destination = "$env:ProgramData\Citrix\7.5"
            DependsOn = "[xRemoteFile]xdMedia"
        }
        
        Citrix_XenDesktopRole xdRole
        {
            Ensure = "Present"
            XenDesktopRole = "SessionVDA"
            XenDesktopController = $XenDesktopController
            XenDesktopMediaPath = "$env:ProgramData\Citrix\7.5"
            DependsOn = "[Archive]xdMediaUnzip"
        }
    }  # close of Node
}  # close of configuration

Configuration Controller
{

    Param
    (
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $mediaUri,

        [Parameter(Mandatory = $true)] 
        [string]$MachineName, 
 
        [Parameter(Mandatory = $true)]
        [string]$Domain,
 
        [Parameter(Mandatory = $true)]
        [pscredential]$DomainCredential,

        [Parameter(Mandatory = $true)]
        [string] $SiteName
    )

    Import-DscResource -Module CitrixXenDesktop
    Import-DscResource -Module CitrixXenDesktopAutomation
    Import-DscResource -Module xPsDesiredStateConfiguration
    Import-DscResource -Module DiskImage
    Import-DscResource -Module cComputerManagement

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
        cComputer JoinDomain
        {
            Name          = $MachineName
            DomainName    = $Domain
            Credential    = $DomainCredential  # Credential to join to domain
        }

        File citrixFolder
        {
            Ensure = "Present"
            Type = "Directory"
            DestinationPath = "$env:ProgramData\Citrix\EasyButton"
            DependsOn = "[cComputer]JoinDomain"
        }

        xRemoteFile xdMedia
        {
            DestinationPath = "$env:ProgramData\Citrix\XenDesktop75.zip"
            Uri = $mediaUri
            DependsOn = "[File]citrixFolder"
        }

        Archive xdMediaUnzip
        {
            Ensure = "Present"
            Path = "$env:ProgramData\Citrix\XenDesktop75.zip"
            Destination = "$env:ProgramData\Citrix\7.5"
            DependsOn = "[xRemoteFile]xdMedia"
        }
        
        Citrix_XenDesktopRole xdRole
        {
            Ensure = "Present"
            XenDesktopRole = "Controller"
            XenDesktopMediaPath = "$env:ProgramData\Citrix\7.5"
            DependsOn = "[Archive]xdMediaUnzip"
        }

        Citrix_XenDesktopDatabase xdDb
        {
            Ensure = "Present"
            DatabaseServer = "localhost"
            DatabaseCredential = $DomainCredential
            XenDesktopController = "localhost"
            SiteName = $SiteName
            DependsOn = "[Citrix_XenDesktopRole]xdRole"
        }

        Citrix_XenDesktopSite xdSite
        {
            Ensure = "Present"
            DatabaseServer = "localhost"
            XenDesktopController = "localhost"
            SiteName = $SiteName
            UserToMakeAdmin = $DomainCredential.UserName
            DependsOn = "[Citrix_XenDesktopDatabase]xdDb"
        }
    }  # close of Node
}  # close of configuration